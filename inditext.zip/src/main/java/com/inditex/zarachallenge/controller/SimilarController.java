package com.inditex.zarachallenge.controller;

public class SimilarController {

	// TODO: Insert code in this controller
}
